CREATE FUNCTION process_campaign_insert () RETURNS trigger
	LANGUAGE plpgsql
AS $$
	BEGIN
  	  IF (TG_OP = 'INSERT') THEN
        	INSERT INTO campaign_revshare(campaign) VALUES (NEW.id);
        	RETURN NEW;
    	END IF;
    	RETURN NULL; -- result is ignored since this is an AFTER trigger
	END;
$$
