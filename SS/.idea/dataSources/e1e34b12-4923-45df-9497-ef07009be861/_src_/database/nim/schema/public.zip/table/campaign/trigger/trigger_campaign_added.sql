CREATE TRIGGER trigger_campaign_added
AFTER INSERT ON campaign
FOR EACH ROW EXECUTE PROCEDURE process_campaign_insert()