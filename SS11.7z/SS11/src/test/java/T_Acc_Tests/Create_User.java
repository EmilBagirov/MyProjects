package T_Acc_Tests;
import DB_requests.DB_test;
import org.junit.Test;
import t_acc.User_Creation;
import java.io.IOException;
import java.sql.SQLException;

public class Create_User {
    User_Creation user;
    DB_test db;

    @Test
    public void createAccApi () throws IOException {
        user.create();
    }

    @Test
    public void DB_test1() throws SQLException {
        db.DB_test();
    }



}
