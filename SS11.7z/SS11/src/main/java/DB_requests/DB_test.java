package DB_requests;
import java.sql.*;

public class DB_test {


    public static void DB_test() throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:postgresql://192.168.200.26:5432/nim","readonly", "4your3y3sonly");
        String selectTableSQL = "SELECT ud.id FROM user_detail as ud WHERE ud.email='4yjottcd7m@yopmail.com'";
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(selectTableSQL);

            while (rs.next()) {
                String udid = rs.getString("ud.id");
                String username = rs.getString("USERNAME");

                System.out.println("ud_id : " + udid);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
